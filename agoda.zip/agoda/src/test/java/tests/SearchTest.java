//////package tests;
//////
//////import base.BaseClass;
//////import org.openqa.selenium.By;
//////import org.openqa.selenium.WebDriver;
//////import org.openqa.selenium.support.ui.ExpectedConditions;
//////import org.openqa.selenium.support.ui.WebDriverWait;
//////import org.testng.Assert;
//////import org.testng.annotations.*;
//////import pages.HomePage;
//////import pages.SearchPage;
//////import utils.ExcelUtil;
//////
//////import java.time.Duration;
//////
//////public class SearchTest extends BaseClass {
//////
//////    // Locator for homepage search input
//////    private final By destinationInput = By.xpath("//input[@aria-label=\"Enter a destination or property\"]");
//////
//////    @BeforeMethod
//////    public void setUpMethod() {
//////        initializeDriver();
//////        HomePage home = new HomePage(driver);
//////        home.openWebsite();
//////        home.closeGooglePopupIfPresent();
//////        waitForHomePageReady(driver);
//////    }
//////
//////    @AfterMethod
//////    public void tearDownMethod() {
//////        quitDriver();
//////    }
//////
//////    @DataProvider(name = "searchData")
//////    public Object[][] getSearchData() throws Exception {
//////        Object[][] data = ExcelUtil.getTestDataFromClasspath("testdata1.xlsx", "Sheet1");
//////
//////        System.out.println("=== DataProvider Debug Info ===");
//////        System.out.println("Rows read: " + data.length);
//////        for (Object[] row : data) {
//////            System.out.println(java.util.Arrays.toString(row));
//////        }
//////        System.out.println("================================");
//////
//////        if (data.length == 0) {
//////            throw new RuntimeException("No test data found in Excel file!");
//////        }
//////        return data;
//////    }
//////
//////    @Test(dataProvider = "searchData")
//////    public void searchTest(String destination, String adults, String rooms) {
//////        System.out.printf("Running with: Destination=%s, Adults=%s, Rooms=%s%n",
//////                destination, adults, rooms);
//////
//////        SearchPage search = new SearchPage(driver);
//////
//////        search.setDestination(destination);
//////        search.pickBlueSelectedDates();
//////        search.setGuestsRooms(Integer.parseInt(adults), Integer.parseInt(rooms));
//////        search.clickSearchAndWait();
//////
//////        Assert.assertTrue(search.isResultsLoaded(),
//////                "❌ Results page did not load after search for: " + destination);
//////    }
//////
//////    /** Helper wait method */
//////    private void waitForHomePageReady(WebDriver driver) {
//////        new WebDriverWait(driver, Duration.ofSeconds(10))
//////                .until(ExpectedConditions.visibilityOfElementLocated(destinationInput));
//////    }
//////}
////
////package tests;
////
////import base.BaseClass;
////import org.testng.Assert;
////import org.testng.annotations.*;
////import pages.HomePage;
////import pages.SearchPage;
////import utils.ExcelUtil;
////
////public class SearchTest extends BaseClass {
////
////    @BeforeMethod
////    public void setUp() {
////        initializeDriver();
////        HomePage home = new HomePage(driver);
////        home.openWebsite();
////        home.closeGooglePopupIfPresent();
////        home.waitUntilReady();
////    }
////
////    @AfterMethod
////    public void tearDown() {
////        quitDriver();
////    }
////
////    @DataProvider(name = "searchData")
////    public Object[][] getSearchData() throws Exception {
////        // Now uses the short ExcelUtil version
////        return ExcelUtil.getTestData("testdata1.xlsx", "Sheet1");
////    }
////
////    @Test(dataProvider = "searchData")
////    public void searchTest(String destination,
////                            String nights,
////                            String month,
////                            String includeWeekendFlag) {
////
////        SearchPage search = new SearchPage(driver);
////
////        search.setDestination(destination);
////        search.selectFlexibleDates(Integer.parseInt(nights), month, Boolean.parseBoolean(includeWeekendFlag));
////        search.clickSearchAndWait();
////
////        Assert.assertTrue(search.isResultsLoaded(),
////                "❌ Results page did not load for: " + destination);
////    }
////}
//
//
//package tests;
//
//import base.BaseClass;
//import org.testng.Assert;
//import org.testng.annotations.*;
//import pages.HomePage;
//import pages.SearchPage;
//import utils.ExcelUtil;
//
//public class SearchTest extends BaseClass {
//
//    @BeforeMethod
//    public void setUp() {
//        initializeDriver();
//        HomePage home = new HomePage(driver);
//        home.openWebsite();
//        home.closeGooglePopupIfPresent();
//        home.waitUntilReady();
//    }
//
//    @AfterMethod
//    public void tearDown() {
//        quitDriver();
//    }
//
//    @DataProvider(name = "searchData")
//    public Object[][] getSearchData() throws Exception {
//        // If Excel has only destinations col now
//        return ExcelUtil.getTestData("testdata1.xlsx", "Sheet2");
//    }
//
//    @Test(dataProvider = "searchData")
//    public void searchTest(String destination) {
//        SearchPage search = new SearchPage(driver);
//
//        search.setDestination(destination);
//        search.selectFlexibleDates();
//        search.clickSearchAndWait();
//
//        Assert.assertTrue(search.isResultsLoaded(),
//                "❌ Results page did not load for: " + destination);
//    }
//}


package tests;

import base.BaseClass;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.HomePage;
import pages.SearchPage;
import utils.ExcelUtil;

public class SearchTest extends BaseClass {

    @BeforeMethod
    public void setUp() {
        initializeDriver();
        HomePage home = new HomePage(driver);
        home.openWebsite();
        home.closeGooglePopupIfPresent();
        home.waitUntilReady();
    }

    @AfterMethod
    public void tearDown() {
        quitDriver();
    }

    @DataProvider(name = "searchData")
    public Object[][] getSearchData() throws Exception {
        return ExcelUtil.getTestData("testdata1.xlsx", "Sheet2");
    }

    @Test(dataProvider = "searchData")
    public void searchTest(String destination) {
        SearchPage search = new SearchPage(driver);
        search.setDestination(destination);
        search.selectFlexibleDates();
        search.clickSearchAndWait();

        Assert.assertTrue(search.isResultsLoaded(),
                "❌ Results page did not load for: " + destination);
    }
}
