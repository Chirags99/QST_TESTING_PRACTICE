//////package pages;
//////
//////import org.openqa.selenium.*;
//////import org.openqa.selenium.support.ui.ExpectedConditions;
//////import org.openqa.selenium.support.ui.WebDriverWait;
//////import java.time.Duration;
//////import java.util.List;
//////
//////public class SearchPage {
//////	WebDriver driver;
//////	WebDriverWait wait;
//////
//////	private By destinationInput = By.xpath("//input[@aria-label=\"Enter a destination or property\"]");
//////	private By firstSuggestion = By.xpath("//*[@id=\"search-box-autocomplete-id\"]/div/ul/li[1]/ul/li[1]");
//////	private By checkInBox = By.xpath("//span[@data-selenium-date=\"2025-08-21\"]");
//////	private By checkOutBox = By.xpath("//span[@data-selenium-date=\"2025-08-22\"]");
//////	// private By selectedDates = By.cssSelector("[aria-selected='true'],
//////	// .is-selected, .CalendarDay--selected, .CalendarDay__selected");
//////	// private By guestsToggle = By.cssSelector("[data-element-name='occupancy'],
//////	// [aria-label*='Guests'], [data-selenium='occupancyBox']");
//////	private By roomsValue = By.xpath("//div[@data-component=\"desktop-occ-room-value\"]");
//////	private By adultsValue = By.xpath("//div[@data-component=\"desktop-occ-adult-value\"]");
//////	private By roomsPlus = By.xpath("(//button[@data-element-name=\"occupancy-selector-panel-rooms\"])[1]");
//////	private By adultsPlus = By.xpath(("//button[@data-element-name='occupancy-selector-panel-adult'])[1]"));
//////	private By searchButton = By.cssSelector("#Tabs-Container > button > div > div > span");
//////
//////	public SearchPage(WebDriver driver) {
//////		this.driver = driver;
//////		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//////	}
//////
//////	public void setDestination(String destination) {
//////		WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(destinationInput));
//////		input.click();
//////		input.clear();
//////		input.sendKeys(destination);
//////		try {
//////			WebElement first = new WebDriverWait(driver, Duration.ofSeconds(5))
//////					.until(ExpectedConditions.visibilityOfElementLocated(firstSuggestion));
//////			first.click();
//////		} catch (Exception e) {
//////			input.sendKeys(Keys.ENTER); // fallback
//////		}
//////	}
//////
//////	public void pickBlueSelectedDates() {
//////		driver.findElement(checkInBox).click();
//////		driver.findElement(checkOutBox).click();
//////	}
//////
//////	public void setGuestsRooms(int adults, int rooms) {
//////		// try {
//////		// wait.until(ExpectedConditions.elementToBeClickable(guestsToggle)).click(); }
//////		// catch (Exception ignored) { }
//////
//////		// Increase adults
//////		int maxTries = 5;
//////		while (maxTries-- > 0) {
//////			Integer curr = valueOfInput(adultsValue);
//////			if (curr != null && curr >= adults)
//////				break;
//////			driver.findElement(adultsPlus).click();
//////		}
//////		// Increase rooms
//////		maxTries = 5;
//////		while (maxTries-- > 0) {
//////			Integer curr = valueOfInput(roomsValue);
//////			if (curr != null && curr >= rooms)
//////				break;
//////			driver.findElement(roomsPlus).click();
//////		}
//////	}
//////
//////	private Integer valueOfInput(By locator) {
//////		try {
//////			WebElement el = driver.findElement(locator);
//////			String val = el.getAttribute("value");
//////			return (val == null || val.isBlank()) ? null : Integer.parseInt(val.replaceAll("[^0-9]", ""));
//////		} catch (Exception e) {
//////			return null;
//////		}
//////	}
//////
//////	public void clickSearchAndWait() {
//////		try {
//////			wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
//////		} catch (Exception e) {
//////			driver.switchTo().activeElement().sendKeys(Keys.ENTER);
//////		}
//////		try {
//////			Thread.sleep(5000);
//////		} catch (InterruptedException ignored) {
//////		}
//////	}
//////
//////	public boolean isResultsLoaded() {
//////		return driver.getCurrentUrl().contains("search");
//////	}
//////}
////
////
////package pages;
////
////import org.openqa.selenium.*;
////import org.openqa.selenium.support.ui.ExpectedConditions;
////import org.openqa.selenium.support.ui.WebDriverWait;
////import java.time.Duration;
////
////public class SearchPage {
////    private final WebDriver driver;
////    private final WebDriverWait wait;
////
////    private final By destinationInput = By.xpath("//input[@aria-label='Enter a destination or property']");
////    private final By firstSuggestion  = By.xpath("//*[@id='search-box-autocomplete-id']/div/ul/li[1]/ul/li[1]");
////    private final By flexibleOption   = By.xpath("//button[@data-element-name='search-box-flexible-dates-tab']");
////    private final By selectButton     = By.xpath("//button[@data-element-name='search-box-flexible-dates-select-button']");
////    private final By searchButton     = By.cssSelector("#Tabs-Container > button > div > div > span");
////
////    public SearchPage(WebDriver driver) {
////        this.driver = driver;
////        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
////    }
////
////    public void setDestination(String destination) {
////        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(destinationInput));
////        input.clear();
////        input.sendKeys(destination);
////        try {
////            wait.until(ExpectedConditions.visibilityOfElementLocated(firstSuggestion)).click();
////        } catch (Exception e) {
////            input.sendKeys(Keys.ENTER);
////        }
////    }
////
////    public void selectFlexibleDates(int nights, String month, boolean includeWeekend) {
////        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 100)");
////        wait.until(ExpectedConditions.elementToBeClickable(flexibleOption)).click();
////        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@label,'" + nights + " nights')]"))).click();
////
////        if (includeWeekend) {
////            try {
////                wait.until(ExpectedConditions.elementToBeClickable(
////                        By.xpath("//label[contains(.,'Must include weekend')]")
////                )).click();
////            } catch (Exception ignored) {}
////        }
////
////        String monthLower = month.toLowerCase();
////        wait.until(ExpectedConditions.elementToBeClickable(
////                By.xpath("//button[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '" + monthLower + "')]")
////        )).click();
////
////        wait.until(ExpectedConditions.elementToBeClickable(selectButton)).click();
////    }
////
////    public void clickSearchAndWait() {
////        try {
////            wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
////        } catch (Exception e) {
////            driver.switchTo().activeElement().sendKeys(Keys.ENTER);
////        }
////        wait.until(ExpectedConditions.urlContains("search")); // smarter wait instead of Thread.sleep
////    }
////
////    public boolean isResultsLoaded() {
////        return driver.getCurrentUrl().contains("search");
////    }
////}
////
//
//
//package pages;
//
//import org.openqa.selenium.*;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import java.time.Duration;
//
//public class SearchPage {
//    private final WebDriver driver;
//    private final WebDriverWait wait;
//
//    // Destination input + first suggestion
//    private final By destinationInput = By.xpath("//input[@aria-label='Enter a destination or property']");
//    private final By firstSuggestion  = By.xpath("//*[@id='search-box-autocomplete-id']/div/ul/li[1]/ul/li[1]");
//
//    // Flexible Dates UI
//    private final By flexibleOption   = By.xpath("//button[@data-element-name='search-box-flexible-dates-tab']");
//    private final By threeNightsChip  = By.xpath("//*[@data-testid='flexible-dates-3-days-chip']");
//    private final By septemberButton  = By.xpath("//button[@id='8']");  // September month chip
//    private final By selectButton     = By.xpath("//button[@data-element-name='search-box-flexible-dates-select-button']");
//
//    // Search button
//    private final By searchButton     = By.cssSelector("#Tabs-Container > button > div > div > span");
//
//    public SearchPage(WebDriver driver) {
//        this.driver = driver;
//        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(15));
//    }
//
//    /** Type destination and select first suggestion */
//    public void setDestination(String destination) {
//        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(destinationInput));
//        input.clear();
//        input.sendKeys(destination);
//        try {
//            wait.until(ExpectedConditions.visibilityOfElementLocated(firstSuggestion)).click();
//        } catch (Exception e) {
//            input.sendKeys(Keys.ENTER);
//        }
//    }
//
//    /** Select 3 nights (fixed), September (fixed), no weekend toggle */
//    public void selectFlexibleDates() {
//        // Scroll a bit in case sticky elements hide the flexible tab
//        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 100)");
//
//        // Click “I’m Flexible” tab
//        wait.until(ExpectedConditions.elementToBeClickable(flexibleOption)).click();
//
//        // Click 3 nights chip
//        wait.until(ExpectedConditions.elementToBeClickable(threeNightsChip)).click();
//
//        // Click September button
//        wait.until(ExpectedConditions.elementToBeClickable(septemberButton)).click();
//
//        // Confirm
//        wait.until(ExpectedConditions.elementToBeClickable(selectButton)).click();
//    }
//
//    /** Click Search and wait for results */
//    public void clickSearchAndWait() {
//        try {
//            wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
//        } catch (Exception e) {
//            driver.switchTo().activeElement().sendKeys(Keys.ENTER);
//        }
//        wait.until(ExpectedConditions.urlContains("search"));
//    }
//
//    /** Verify results page loaded */
//    public boolean isResultsLoaded() {
//        return driver.getCurrentUrl().contains("search");
//    }
//}


package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;

public class SearchPage {
    private final WebDriver driver;
    private final WebDriverWait wait;

    // Destination
    private final By destinationInput = By.xpath("//input[@aria-label='Enter a destination or property']");
    private final By firstSuggestion  = By.xpath("//*[@id='search-box-autocomplete-id']//li[1]");

    // Flexible Dates (fixed locators)
    private final By flexibleOption = By.xpath("//p[@data-action='tab-selector-1']");
    private final By threeNightsChip  = By.xpath("//*[@data-testid='flexible-dates-3-days-chip']");
    private final By septemberButton  = By.xpath("(//section[@style=\"min-width: 100px; max-width: 100px;\"])[2]");
    private final By selectButton     = By.xpath("//button[@data-testid=\"flexible-dates-select-button\"]");

    // Search button
    private final By searchButton = By.cssSelector("#Tabs-Container > button > div > div > span");

    public SearchPage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void setDestination(String destination) {
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(destinationInput));
        input.clear();
        input.sendKeys(destination);
        try {
            wait.until(ExpectedConditions.elementToBeClickable(firstSuggestion)).click();
        } catch (Exception e) {
            input.sendKeys(Keys.ENTER);
        }
    }

    public void selectFlexibleDates() {
        wait.until(ExpectedConditions.elementToBeClickable(flexibleOption)).click();
        wait.until(ExpectedConditions.elementToBeClickable(threeNightsChip)).click();
        wait.until(ExpectedConditions.elementToBeClickable(septemberButton)).click();
        wait.until(ExpectedConditions.elementToBeClickable(selectButton)).click();
    }

    public void clickSearchAndWait() {
        wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
        wait.until(ExpectedConditions.urlContains("search"));
    }

    public boolean isResultsLoaded() {
        return driver.getCurrentUrl().contains("search");
    }
}
