//package pages;
//
//import org.openqa.selenium.*;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import java.time.Duration;
//
//public class HomePage {
//    WebDriver driver;
//
//    // Google Sign-in close button 
//    private final By googlePopupClose = By.xpath("//button[@aria-label=\"Close\"]");
//
//    public HomePage(WebDriver driver) {
//        this.driver = driver;
//    }
//
//    public void openWebsite() {
//        driver.get("https://www.agoda.com/");
//    }
//
//    public void closeGooglePopupIfPresent() {
//        try {
//            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
//            WebElement closeBtn = wait.until(ExpectedConditions.elementToBeClickable(googlePopupClose));
//            closeBtn.click();
//        } catch (Exception ignored) {}
//    }
//}


package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class HomePage {
    WebDriver driver;
    private final By googlePopupClose = By.xpath("//button[@aria-label='Close']");
    private final By destinationInput = By.xpath("//input[@aria-label=\"Enter a destination or property\"]");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void openWebsite() {
        driver.get("https://www.agoda.com/");
    }

    public void closeGooglePopupIfPresent() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
            WebElement closeBtn = wait.until(ExpectedConditions.elementToBeClickable(googlePopupClose));
            closeBtn.click();
        } catch (Exception ignored) {}
    }

    public void waitUntilReady() {
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOfElementLocated(destinationInput));
    }
}
