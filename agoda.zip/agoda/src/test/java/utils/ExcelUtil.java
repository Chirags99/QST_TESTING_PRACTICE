//package utils;
//
//import org.apache.poi.ss.usermodel.*;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import java.io.InputStream;
//
//public class ExcelUtil {
//
//    public static Object[][] getTestData(String fileName, String sheetName) throws Exception {
//        try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
//             Workbook wb = new XSSFWorkbook(is)) {
//
//            Sheet sheet = wb.getSheet(sheetName);
//            int rows = sheet.getPhysicalNumberOfRows();
//            int cols = sheet.getRow(0).getPhysicalNumberOfCells();
//
//            DataFormatter fmt = new DataFormatter();
//            Object[][] data = new Object[rows - 1][cols];
//
//            for (int i = 1; i < rows; i++) {
//                for (int j = 0; j < cols; j++) {
//                    data[i - 1][j] = fmt.formatCellValue(sheet.getRow(i).getCell(j));
//                }
//            }
//            return data;
//        }
//    }
//}


package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.InputStream;

public class ExcelUtil {

    public static Object[][] getTestData(String fileName, String sheetName) throws Exception {
        try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
             Workbook wb = new XSSFWorkbook(is)) {

            Sheet sheet = wb.getSheet(sheetName);
            int rows = sheet.getPhysicalNumberOfRows();
            int cols = sheet.getRow(0).getPhysicalNumberOfCells();

            DataFormatter fmt = new DataFormatter();
            Object[][] data = new Object[rows - 1][cols];

            for (int i = 1; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    data[i - 1][j] = fmt.formatCellValue(sheet.getRow(i).getCell(j)).trim();
                }
            }
            return data;
        }
    }
}
