package tests;

import base.BaseClass;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.HomePage;
import pages.SearchPage;
import utils.ExcelUtil;

public class SearchTest extends BaseClass {

    @BeforeMethod
    public void setUp() throws Exception {
        initializeDriver();
        HomePage home = new HomePage(driver);
        home.openWebsite();
        home.closeGooglePopupIfPresent();
        home.waitUntilReady();
    }

    @AfterMethod
    public void tearDown() {
        quitDriver();
    }

    @DataProvider(name = "searchData")
    public Object[][] getSearchData() throws Exception {
        return ExcelUtil.getTestData("testdata1.xlsx", "Sheet1");
    }

    @Test(dataProvider = "searchData")
    public void searchTest(String destination) throws Exception {
        SearchPage search = new SearchPage(driver);
        search.setDestination(destination);
        search.selectFlexibleDates();
        search.clickSearchAndWait();

        Assert.assertTrue(search.isResultsLoaded(),
                "❌ Results page did not load for: " + destination);
    }
}
