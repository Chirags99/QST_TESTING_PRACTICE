package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.InputStream;

public class ExcelUtil {

    // Get test data (Sheet1)
    public static Object[][] getTestData(String fileName, String sheetName) throws Exception {
        try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
             Workbook wb = new XSSFWorkbook(is)) {

            Sheet sheet = wb.getSheet(sheetName);
            int rows = sheet.getPhysicalNumberOfRows();
            int cols = sheet.getRow(0).getPhysicalNumberOfCells();

            DataFormatter fmt = new DataFormatter();
            Object[][] data = new Object[rows - 1][cols];

            for (int i = 1; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    data[i - 1][j] = fmt.formatCellValue(sheet.getRow(i).getCell(j)).trim();
                }
            }
            return data;
        }
    }

    // Get locator + action (Sheet2)
    public static String[] getLocator(String fileName, String sheetName, String locatorKey) throws Exception {
        try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
             Workbook wb = new XSSFWorkbook(is)) {

            Sheet sheet = wb.getSheet(sheetName);
            DataFormatter fmt = new DataFormatter();

            for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
                String key = fmt.formatCellValue(sheet.getRow(i).getCell(0)).trim();
                if (key.equalsIgnoreCase(locatorKey)) {
                    String type   = fmt.formatCellValue(sheet.getRow(i).getCell(1)).trim();
                    String value  = fmt.formatCellValue(sheet.getRow(i).getCell(2)).trim();
                    String action = fmt.formatCellValue(sheet.getRow(i).getCell(3)).trim();
                    return new String[]{type, value, action};
                }
            }
        }
        throw new RuntimeException("❌ Locator not found in Excel: " + locatorKey);
    }
}
