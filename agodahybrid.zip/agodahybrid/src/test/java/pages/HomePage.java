package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import utils.ExcelUtil;

import java.time.Duration;

public class HomePage {
    WebDriver driver;
    WebDriverWait wait;

    private final String fileName = "testdata1.xlsx";
    private final String sheetName = "Sheet2";

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    private By getBy(String type, String value) {
        switch (type.toLowerCase()) {
            case "id": return By.id(value);
            case "name": return By.name(value);
            case "css": return By.cssSelector(value);
            case "xpath": return By.xpath(value);
            default: throw new IllegalArgumentException("❌ Invalid locator type: " + type);
        }
    }

    private void performStep(String locatorKey, String testData) throws Exception {
        String[] locatorData = ExcelUtil.getLocator(fileName, sheetName, locatorKey);
        String type   = locatorData[0];
        String value  = locatorData[1];
        String action = locatorData[2];

        By locator = getBy(type, value);

        switch (action.toLowerCase()) {
            case "click":
                wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
                break;

            case "type":
                WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
                if (testData != null && !testData.isEmpty()) {   // ✅ FIX
                    input.clear();
                    input.sendKeys(testData);
                }
                break;

            case "verify":
                wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
                break;

            default:
                throw new IllegalArgumentException("❌ Unknown action in Excel: " + action);
        }
    }


    public void openWebsite() {
        driver.get("https://www.agoda.com/");
    }

    public void closeGooglePopupIfPresent() throws Exception {
        try {
            performStep("googlePopupClose", null);
        } catch (Exception ignored) {}
    }

    public void waitUntilReady() throws Exception {
        performStep("destinationInput", null); // just waits/verify
    }
}
