package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import utils.ExcelUtil;

import java.time.Duration;

public class SearchPage {
    private final WebDriver driver;
    private final WebDriverWait wait;
    private final String fileName = "testdata1.xlsx";
    private final String sheetName = "Sheet2";

    public SearchPage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    private By getBy(String type, String value) {
        switch (type.toLowerCase()) {
            case "id": return By.id(value);
            case "name": return By.name(value);
            case "css": return By.cssSelector(value);
            case "xpath": return By.xpath(value);
            default: throw new IllegalArgumentException("❌ Invalid locator type: " + type);
        }
    }

    private void performStep(String locatorKey, String testData) throws Exception {
        String[] locatorData = ExcelUtil.getLocator(fileName, sheetName, locatorKey);
        String type   = locatorData[0];
        String value  = locatorData[1];
        String action = locatorData[2];

        By locator = getBy(type, value);

        switch (action.toLowerCase()) {
            case "click":
                wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
                break;
            case "type":
                WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
                input.clear();
                input.sendKeys(testData);
                break;
            case "verify":
                wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
                break;
        }
    }

    public void setDestination(String destination) throws Exception {
        performStep("destinationInput", destination);
        try {
            performStep("firstSuggestion", null);
        } catch (Exception e) {
            // fallback if suggestion not clickable
        }
    }

    public void selectFlexibleDates() throws Exception {
        performStep("flexibleOption", null);
        performStep("threeNightsChip", null);
        performStep("septemberButton", null);
        performStep("selectButton", null);
    }

    public void clickSearchAndWait() throws Exception {
        performStep("searchButton", null);
        wait.until(ExpectedConditions.urlContains("search"));
    }

    public boolean isResultsLoaded() {
        return driver.getCurrentUrl().contains("search");
    }
}
